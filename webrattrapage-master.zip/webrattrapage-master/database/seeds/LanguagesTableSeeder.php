<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LanguagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('languages')->insert([
            'name' => "C/C++",
            'site' => "https://fr.cppreference.com/w/",
            'description' => "Langage de programmation des systemes."
        ]);
        DB::table('languages')->insert([
            'name' => "Java",
            'site' => "https://www.java.com/fr/",
            'description' => "Langage de programmation orientee-objet."
        ]);
        DB::table('languages')->insert([
            'name' => "Caml",
            'site' => "https://caml.inria.fr/ocaml/",
            'description' => "Langage populaire de programmation fonctionneelle."
        ]);
    }
}
