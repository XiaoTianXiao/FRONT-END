<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Language as Language;

class LanguageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getAllLanguages(Request $request)
    {
        $languages = Language::all();
        return view('languages')->with(['languages'=>$languages]);
    }

    public function addLanguage(Request $request)
    {
        $language = new Language;
        $language->name = $request->input('name');
        $language->description = $request->input('description');
        $language->site = $request->input('site');
        if ((empty($language->name)) || (empty($language->description)) || (empty($language->site)))
        {
            $request->session()->flash('status', "Some of parameters is empty, please fill all of it!");
            return view('add_language');
        }
        $language->save();
        $request->session()->flash('status', "Language $language->name successfully added!");
        return redirect('home');
    }
}
