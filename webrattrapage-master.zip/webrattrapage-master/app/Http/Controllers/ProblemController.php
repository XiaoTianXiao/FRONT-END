<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Language as Language;
use App\Problem as Problem;
use App\Program as Program;

class ProblemController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function addProblem(Request $request)
    {
        $language_id = $request->language_id;
        $language = Language::where('id', $language_id)->first();
        if (is_null($language))
        {
            $request->session()->flash('status', "Language not found, please try again!");
            return view('add_problem');
        }
        //Cherher le probleme pour ce langage avec le meme nom 
        //s'il existe deja, il faut ajouter un programm a la place
        $existing_problem = Problem::where('name', $request->input('name'))->
                                    where('language_id', $language_id)->first();
        if (!is_null($existing_problem))
        {
            $request->session()->flash('status', "This problem already exists, please create another one!");
            return view('add_problem');
        }
        $problem = new Problem;
        $problem->language_id = $language_id;
        $problem->name = $request->input('name');

        $problem->code = $request->input('code');
        if ((empty($problem->name)) || (empty($problem->code)))
        {
            $request->session()->flash('status', "Some of parameters is empty, please fill all of it!");
            return view('add_problem');
        }
        $problem->save();
        $request->session()->flash('status', "Problem $problem->name for language $language->name successfully added!");
        return redirect('home');
    }

    public function addProblemPage(Request $request)
    {
        $languages = Language::all();
        return view('add_problem')->with(['languages'=>$languages]);
    }

    public function getProblems(Request $request)
    {
        $languages = Language::all();
        return view('problems')->with(['languages'=>$languages]);
    }

    public function getProblemsForLanguage(Request $request)
    {
        $language_id = $request->language_id;
        $language = Language::where('id', $language_id)->first();
        if (is_null($language))
        {
            $request->session()->flash('status', "Language not found, please try again!");
            return view('add_problem');
        }
        $problems = Problem::where('language_id', $language_id)->get();
        return view('problems_for_language')->with(['problems'=>$problems,
                                                    'language'=>$language]);
    }

    public function getProgramPage(Request $request)
    {
        $user_id = Auth::id();
        $problem = Problem::where('name', $request->problem_name)->first();
        if (is_null($problem))
        {
            $request->session()->flash('status', "Problem with this name not found, please try again!");
            return view('problems_for_language');
        }
        return view('add_program')->with(['problem'=>$problem]);
    }

    public function addProgram(Request $request)
    {
        $problem = Problem::where('name', $request->problem_name)->first();
        return view('add_program')->with(['problem'=>$problem]);
    }
}
