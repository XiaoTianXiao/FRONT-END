@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Espace utilisateur</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <h3><a href="{{ route('languages') }}">Langages de programmation</a>
                    <br>
                    <h3><a href="/home/add_language_page">Ajouter un langage</a>
                    <br>
                    <h3><a href="/home/add_problem_page">Ajout du code</a>
                    <br>
                    <h3><a href="/home/problems">Regarder les problems</a>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
