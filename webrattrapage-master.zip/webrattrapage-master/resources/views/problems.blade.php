@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Regarder des problemes</div>
                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <form class="form-horizontal" method="POST" action="{{ route('problems_for_language') }}">
                        {{ csrf_field() }}
                        <div class="form-group{{ $errors->has('language_id') ? ' has-error' : '' }}">
                            <label for="language_id" class="col-md-4 control-label">Langage</label>

                            <div class="col-md-6 col-md-offset-4">
                                <select name = "language_id" class="form-control" id="language_id" required autofocus>
                                    @if (isset($languages))
                                        @foreach ($languages as $language)
                                            <option value="{{ $language->id }}">{{ $language->name }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Chercher
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <a href="{{ route('home') }}" class="btn btn-primary">
                                Retourner
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection