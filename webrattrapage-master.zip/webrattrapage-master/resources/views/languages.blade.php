@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Liste de tous les langages</div>
                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @if (isset($languages))
                        @forelse ($languages as $language)
                            <p>{{ $language->name }} <a href="{{ $language->site }}">{{ $language->site }}</a></p>
                            {{ $language->description }}
                            <br>
                            <br>
                        @empty
                            <p>Aucune langage ajoute'</p>
                        @endforelse
                    @endif
                    <br>
                    <div class="col-md-6 col-md-offset-0">
                        <a href="{{ route('home') }}" class="btn btn-primary">
                        Retourner
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection