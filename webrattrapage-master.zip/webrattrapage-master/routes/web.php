<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/home/languages', 'LanguageController@getAllLanguages')->name('languages');

Route::get('/home/add_language_page', function () {
    return view('add_language');
});
Route::get('/home/add_problem_page', 'ProblemController@addProblemPage');

Route::get('/home/problems', 'ProblemController@getProblems')->name('problems');

Route::get('/home/problems/{problem_name}', 'ProblemController@getProgramPage')->name('add_program_page');

Route::post('/home/problems/for_language', 'ProblemController@getProblemsForLanguage')->name('problems_for_language');

Route::post('/home/add_language', 'LanguageController@addLanguage')->name('add_language');

Route::post('/home/add_problem/', 'ProblemController@addProblem')->name('add_problem');

Route::post('/home/problem/add_program', 'ProblemController@addProgram')->name('add_program');
