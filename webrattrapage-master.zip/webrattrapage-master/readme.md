#TP_NOTE de programmation web 2

Dans ce TP j'ai utilisé le framework populaire de PHP
Laravel de version 5.5 pour qu'il pourrait etre lancé
sur les machines ayant au moins la version 7.0.33 de PHP (celle de *osr-etudiant*).
Ce framework nous permet d'integrer facilement le systeme de 
**login** et respecter les consignes de la modele **MVC**.
La partie **view** est faite en utilisant le syntax **Blade**.
Les fichiers se retrouvent dans la repertoire **/ressources/views**.
Les table dans la base de données sont creés à l'aide de la commande
`php artisan migrate` avec tous les migrations qui se retrouvent dans 
la repértoire **/database/migrations**.

## Setup

Suivez les instructions ci-dessous pour lancer le projet:

1. Clonez le repo
2. Installez composer dans le racine du projet: https://getcomposer.org/download/
3. Configurez votre enviroment en se basant sur.env.example
4. Lancez `php composer.phar install && php composer.phar update`

Maintenant votre projet est pret pour etre lance':
    `php artisan serve`

Si vous voulez utiliser les données par defaut, faites
   `php artisan db:seed`
